Three libraries were apt installed for this project:
libzmq3-dev, libzmqpp-dev, and nlohmann-json3-dev

Part 1 and 2 are in the same directory. 
Run make in hw2/part1-2/ to compile, and ./main to run.

Space bar pauses the timeline, 2 sets half speed, 
3 sets double speed, and 1 resets to normal speed.

Part 3 and 4 each have their own directory.
For part 3, run make in hw2/part3 to compile,
the executables will be ./server and ./client

For part 4, run make in hw2/part4 to compile, which will create two executables.
./main will start the server, which has an SFML window similar to part 1 and 2.
./client will start a client, connecting to the server and creating a new character.

